# Simulate handshake protocol to detect alien metadata phase shifts

def simulate_handshake(node_id, metadata):
    print(f"[{node_id}] Initiating handshake...")
    if "entropy_signature" in metadata:
        if metadata["entropy_signature"] < 0.002:
            return "Unstable Node Detected"
    return "Handshake Accepted"
