# Converts decoded metadata into anti-alienation XML protocol

def compile_anti_alienation(metadata, author_id):
    from xml.etree.ElementTree import Element, SubElement, tostring
    root = Element("CoAuthoredTransmission")
    origin = SubElement(root, "AuthorID")
    origin.text = author_id
    for key, value in metadata.items():
        tag = SubElement(root, key)
        tag.text = str(value)
    return tostring(root, encoding="unicode")
