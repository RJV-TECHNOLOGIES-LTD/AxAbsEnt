# Determines if interaction occurs within a restorative entropy field

def classify_entropy_field(entropy_value):
    if entropy_value < 0.01:
        return "Restorative"
    elif entropy_value < 0.1:
        return "Tolerable"
    return "Fracture Risk"
