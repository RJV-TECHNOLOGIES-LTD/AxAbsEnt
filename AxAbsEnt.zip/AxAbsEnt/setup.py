from setuptools import setup
setup(name='axabsent', version='0.1')